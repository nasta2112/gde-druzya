package com.example.friendsmap

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Handler
import android.widget.Toast
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Email
import org.osmdroid.util.BoundingBox
import kotlin.math.abs
import kotlin.math.sqrt
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Shader
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.unit.Dp
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.draw.scale
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.os.BatteryManager
import android.os.Bundle
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

var darkTheme by mutableStateOf(false)
val Periwinkle get() = if (darkTheme) Color(0xFF55659B) else Color(0xFFA7B7E0)
val Lavender get() = if (darkTheme) Color(0xFF6A5C99) else Color(0xFFC7BCE4)
val Milk get() = if (darkTheme) Color(0xFF14172B) else Color(0xFFF5F6F0)
val Deep get() = if (darkTheme) Color(0xFF9FB0F0) else Color(0xFF5C6DB0)
val Ink get() = if (darkTheme) Color(0xFFE8EAF6) else Color(0xFF2E3354)
val Panel get() = if (darkTheme) Color(0xFF1F2340) else Color.White

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osm", Context.MODE_PRIVATE))
        darkTheme = getSharedPreferences("fm", Context.MODE_PRIVATE).getBoolean("dark", false)
        Configuration.getInstance().userAgentValue = "GdeDruzyaFriendsMap/1.0 (Android; personal friends-location project)"
        setContent {
            val onP = if (darkTheme) Color(0xFF14172B) else Color(0xFFF5F6F0)
            val cs = if (darkTheme) darkColorScheme(
                primary = Deep, onPrimary = onP, secondary = Lavender, onSecondary = Ink,
                primaryContainer = Periwinkle, onPrimaryContainer = Ink,
                background = Milk, surface = Milk, onSurface = Ink, onBackground = Ink
            ) else lightColorScheme(
                primary = Deep, onPrimary = onP, secondary = Lavender, onSecondary = Ink,
                primaryContainer = Periwinkle, onPrimaryContainer = Ink,
                background = Milk, surface = Milk, onSurface = Ink, onBackground = Ink
            )
            MaterialTheme(colorScheme = cs, shapes = Shapes(extraSmall = RoundedCornerShape(16.dp), small = RoundedCornerShape(18.dp), medium = RoundedCornerShape(22.dp))) {
                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 20.dp)) { App() }
                }
            }
        }
    }
}

data class Friend(val id: String, val name: String, val lat: Double, val lng: Double, val ts: Long, val bat: Int = -1, val speed: Int = 0, val steps: Int = -1, val emoji: String = "")
data class Msg(val key: String, val name: String, val text: String, val ts: Long, val mine: Boolean, val url: String = "", val big: Boolean = false)
data class Chk(val key: String, val name: String, val place: String, val lat: Double, val lng: Double, val ts: Long)

fun postText(url: String, body: String) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        c.responseCode
        c.disconnect()
    } catch (e: Exception) { }
}

fun putImage(url: String, bytes: ByteArray, header: String) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "PUT"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 30000
        c.setRequestProperty("Filename", "meme.jpg"); c.setRequestProperty("Message", header)
        c.outputStream.use { it.write(bytes) }
        c.responseCode; c.disconnect()
    } catch (e: Exception) { }
}

@Composable
fun NetImage(url: String) {
    var bmp by remember(url) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(url) {
        bmp = withContext(Dispatchers.IO) {
            try { URL(url).openStream().use { BitmapFactory.decodeStream(it) }?.asImageBitmap() } catch (e: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.widthIn(max = 240.dp).heightIn(max = 300.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Fit)
    else Box(Modifier.size(120.dp).clip(RoundedCornerShape(18.dp)).background(Lavender), contentAlignment = Alignment.Center) { Text("🖼", fontSize = 32.sp) }
}

fun decodeAva(b64: String): Bitmap? = try {
    val b = Base64.decode(b64, Base64.NO_WRAP); BitmapFactory.decodeByteArray(b, 0, b.size)
} catch (e: Exception) { null }

@Composable
fun AvatarBox(size: Dp, name: String, color: Color, emoji: String, photo: Bitmap?, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
        if (photo != null) Image(photo.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (emoji.isNotEmpty()) emoji else name.take(1).uppercase(), color = Color.White,
            fontSize = (size.value * 0.45f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SettingRow(title: String, sub: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, style = MaterialTheme.typography.bodySmall) }
        Switch(v, onChange)
    }
}

val emojis = listOf("😀","😂","🤣","😊","😍","😘","😎","🤔","😅","😭","😡","🥳","😴","🤗","🙄","😏","👍","👎","👏","🙏","🤝","💪","🔥","❤️","💔","✨","🎉","🍕","☕","🚗","🏠","📍","🌧️","☀️","🎧","🍻")
val stickers = listOf("🗿","💀","😭","🤡","🫡","👀","🔥","💯","🤝","🥶","🤯","🫠","😈","🐸","🦆","🍌")

suspend fun listen(url: String, onMsg: (JSONObject) -> Unit, onState: (Boolean) -> Unit) {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 10000; c.readTimeout = 80000
    val h = currentCoroutineContext()[Job]?.invokeOnCompletion { c.disconnect() }
    try {
        c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
            onState(true)
            while (true) {
                val line = r.readLine() ?: break
                try {
                    val o = JSONObject(line)
                    if (o.optString("event") == "message") {
                        val m = JSONObject(o.getString("message"))
                        o.optJSONObject("attachment")?.optString("url")?.let { m.put("u", it) }
                        onMsg(m)
                    }
                } catch (e: Exception) { }
            }
        }
    } finally { h?.dispose(); c.disconnect(); onState(false) }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("fm", Context.MODE_PRIVATE) }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var room by remember { mutableStateOf(prefs.getString("room", "") ?: "") }
    if (room.isBlank()) {
        JoinScreen(name) { n, r ->
            prefs.edit().putString("name", n).putString("room", r).apply()
            name = n; room = r
        }
    } else {
        MapScreen(name, room, prefs, { n -> prefs.edit().putString("name", n).apply(); name = n }) { prefs.edit().remove("room").apply(); room = "" }
    }
}

@Composable
fun JoinScreen(initialName: String, onGo: (String, String) -> Unit) {
    var name by remember { mutableStateOf(initialName) }
    var code by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Periwinkle, Lavender, Milk))).padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) { Text("📍", fontSize = 40.sp) }
        Spacer(Modifier.height(12.dp))
        Text("Где друзья", style = MaterialTheme.typography.displaySmall, color = Ink, fontWeight = FontWeight.Bold)
        Text("Делись геолокацией с друзьями", color = Ink)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Ваше имя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(modifier = Modifier.fillMaxWidth(), onClick = {
            if (name.isBlank()) err = "Введите имя"
            else onGo(name.trim(), (1..8).map { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random() }.joinToString(""))
        }) { Text("Создать комнату") }
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(code, { code = it.uppercase().trim() }, label = { Text("Код комнаты друга") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
            if (name.isBlank()) err = "Введите имя"
            else if (code.length < 6) err = "Введите код комнаты"
            else onGo(name.trim(), code)
        }) { Text("Войти по коду") }
        if (err.isNotEmpty()) Text(err, color = Color(0xFFB3261E), modifier = Modifier.padding(top = 8.dp))
    }
}

val palette = listOf(0xFF7C8FD6, 0xFFA48BD6, 0xFF6FA8DC, 0xFFB39DDB, 0xFF8E9AE6)
fun colorFor(id: String) = Color(palette[(id.hashCode() and 0x7fffffff) % palette.size])

fun avatar(ctx: Context, name: String, bat: Int, speed: Int, color: Int, emoji: String = "", photo: Bitmap? = null): BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val w = (220 * d).toInt(); val h = (82 * d).toInt()
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp); val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val cx = w / 2f; val r = 24 * d; val cy = r + 2 * d
    p.setShadowLayer(5 * d, 0f, 2 * d, 0x66000000); p.color = 0xFFFFFFFF.toInt(); c.drawCircle(cx, cy, r + 3 * d, p); p.clearShadowLayer()
    p.color = color; c.drawCircle(cx, cy, r, p)
    if (photo != null) {
        val sc = Bitmap.createScaledBitmap(photo, (2 * r).toInt(), (2 * r).toInt(), true)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        val sh = BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val mx = Matrix(); mx.setTranslate(cx - r, cy - r); sh.setLocalMatrix(mx)
        sp.shader = sh; c.drawCircle(cx, cy, r, sp)
    }
    p.color = 0xFFFFFFFF.toInt(); p.textAlign = Paint.Align.CENTER; p.textSize = 22 * d; p.isFakeBoldText = true
    if (photo == null) c.drawText(if (emoji.isNotEmpty()) emoji else name.take(1).uppercase(), cx, cy + 8 * d, p)
    val label = buildString { append(name); if (bat >= 0) append(" · $bat%"); if (speed > 3) append(" · $speed км/ч") }
    p.textSize = 12 * d
    val tw = p.measureText(label) + 18 * d
    p.color = 0xFFFFFFFF.toInt(); c.drawRoundRect(cx - tw / 2, 2 * r + 9 * d, cx + tw / 2, 2 * r + 30 * d, 10 * d, 10 * d, p)
    p.color = 0xFF2E3354.toInt(); c.drawText(label, cx, 2 * r + 24 * d, p)
    return BitmapDrawable(ctx.resources, bmp)
}

@SuppressLint("MissingPermission")
@Composable
fun MapScreen(name: String, room: String, prefs: android.content.SharedPreferences, onName: (String) -> Unit, onLeave: () -> Unit) {
    val ctx = LocalContext.current
    val base = "https://ntfy.sh/fm$room"
    val myId = remember {
        prefs.getString("id", null) ?: UUID.randomUUID().toString().take(12).also { prefs.edit().putString("id", it).apply() }
    }
    var friends by remember { mutableStateOf(mapOf<String, Friend>()) }
    var me by remember { mutableStateOf<GeoPoint?>(null) }
    var frozen by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(false) }
    var focus by remember { mutableStateOf<GeoPoint?>(null) }
    var centered by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var tab by remember { mutableStateOf(0) }
    var mySteps by remember { mutableStateOf(-1) }
    var chat by remember { mutableStateOf(listOf<Msg>()) }
    var checkins by remember { mutableStateOf(listOf<Chk>()) }
    var lastShake by remember { mutableStateOf(0L) }
    var draft by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var panel by remember { mutableStateOf(0) }
    val curName by rememberUpdatedState(name)
    var photos by remember { mutableStateOf(mapOf<String, Bitmap>()) }
    var myPhoto by remember { mutableStateOf(prefs.getString("ava", null)?.let { decodeAva(it) }) }
    var myEmoji by remember { mutableStateOf(prefs.getString("emoji", "") ?: "") }
    var nick by remember { mutableStateOf(name) }
    var settings by remember { mutableStateOf(false) }
    val sendAva: (String) -> Unit = { b64 ->
        val j = JSONObject().put("k", "ava").put("i", myId).put("a", b64).put("t", System.currentTimeMillis())
        Thread { postText(base, j.toString()) }.start()
    }
    val avaPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            val src = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val bm = Bitmap.createScaledBitmap(sq, 48, 48, true)
            val out = java.io.ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 55, out)
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            prefs.edit().putString("ava", b64).putString("emoji", "").apply()
            myPhoto = bm; myEmoji = ""; sendAva(b64)
        } catch (e: Exception) { }
    }
    LaunchedEffect(Unit) {
        delay(3000)
        while (true) { prefs.getString("ava", null)?.let { sendAva(it) }; delay(240000) }
    }
    val iconCache = remember { HashMap<String, BitmapDrawable>() }
    val sendChat: (String, Boolean) -> Unit = { tx, big ->
        val j = JSONObject().put("k", "chat").put("i", myId).put("n", name).put("x", tx)
            .put("g", if (big) 1 else 0).put("t", System.currentTimeMillis())
        Thread { postText(base, j.toString()) }.start()
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Thread {
            try {
                val src = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
                val k = 800f / maxOf(src.width, src.height)
                val bm = if (k < 1f) Bitmap.createScaledBitmap(src, (src.width * k).toInt(), (src.height * k).toInt(), true) else src
                val out = java.io.ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 80, out)
                val n64 = Base64.encodeToString(name.toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
                val hdr = JSONObject().put("k", "img").put("i", myId).put("n64", n64).put("t", System.currentTimeMillis()).toString()
                putImage(base, out.toByteArray(), hdr)
            } catch (e: Exception) { }
        }.start()
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        granted = res[Manifest.permission.ACCESS_FINE_LOCATION] == true || res[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }
    LaunchedEffect(Unit) {
        perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACTIVITY_RECOGNITION))
        while (true) { delay(15000); now = System.currentTimeMillis() }
    }
    LaunchedEffect(room) {
        withContext(Dispatchers.IO) {
            while (isActive) {
                try {
                    listen("$base/json?since=30m", { m ->
                        val id = m.optString("i"); val t = m.optLong("t")
                        when (m.optString("k", "loc")) {
                            "chat", "img" -> {
                                val key = id + t
                                val nm = if (m.has("n64")) String(Base64.decode(m.getString("n64"), Base64.URL_SAFE or Base64.NO_PADDING)) else m.optString("n", "?")
                                if (chat.none { it.key == key }) chat = (chat + Msg(key, nm, m.optString("x"), t, id == myId, m.optString("u"), m.optInt("g", 0) == 1)).sortedBy { it.ts }.takeLast(100)
                            }
                            "chk" -> {
                                val key = id + t
                                if (checkins.none { it.key == key }) checkins = (checkins + Chk(key, m.optString("n", "?"), m.optString("p"), m.getDouble("a"), m.getDouble("o"), t)).sortedBy { it.ts }.takeLast(50)
                            }
                            "ava" -> if (id != myId) {
                                val a = m.optString("a")
                                val b = if (a.isEmpty()) null else decodeAva(a)
                                photos = if (b == null) photos - id else photos + (id to b)
                            }
                            "shake" -> {
                                val p = me
                                if (id != myId && p != null && lastShake > 0 && abs(t - lastShake) < 15000 && System.currentTimeMillis() - t < 60000) {
                                    val r = FloatArray(1)
                                    Location.distanceBetween(p.latitude, p.longitude, m.getDouble("a"), m.getDouble("o"), r)
                                    if (r[0] < 300) Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(ctx, "🤝 " + m.optString("n") + " рядом! Встреча!", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                            else -> if (id.isNotEmpty() && id != myId) {
                                friends = friends + (id to Friend(id, m.optString("n", "?"), m.getDouble("a"), m.getDouble("o"),
                                    t, m.optInt("b", -1), m.optInt("s", 0), m.optInt("p", -1), m.optString("e", "")))
                            }
                        }
                    }, { online = it })
                } catch (e: Exception) { }
                delay(3000)
            }
        }
    }
    DisposableEffect(granted, frozen) {
        val client = LocationServices.getFusedLocationProviderClient(ctx)
        val cb = object : LocationCallback() {
            override fun onLocationResult(r: LocationResult) {
                val l = r.lastLocation ?: return
                me = GeoPoint(l.latitude, l.longitude)
                if (!frozen) {
                    val bat = (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
                        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    val j = JSONObject().put("i", myId).put("n", curName).put("a", l.latitude).put("o", l.longitude)
                        .put("t", System.currentTimeMillis()).put("b", bat).put("s", (l.speed * 3.6).toInt()).put("p", mySteps).put("e", myEmoji)
                    Thread { postText(base, j.toString()) }.start()
                }
            }
        }
        if (granted) client.requestLocationUpdates(
            LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000L).build(), cb, Looper.getMainLooper())
        onDispose { client.removeLocationUpdates(cb) }
    }
    DisposableEffect(granted, frozen) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val stepL = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val total = e.values[0].toInt()
                val day = System.currentTimeMillis() / 86400000L
                if (prefs.getLong("stepDay", -1L) != day || total < prefs.getInt("stepBase", Int.MAX_VALUE)) {
                    prefs.edit().putLong("stepDay", day).putInt("stepBase", total).apply()
                }
                mySteps = total - prefs.getInt("stepBase", total)
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        val shakeL = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val g = sqrt((e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()) / 9.81
                val t = System.currentTimeMillis()
                val p = me
                if (g > 2.7 && t - lastShake > 4000 && p != null && !frozen) {
                    lastShake = t
                    Toast.makeText(ctx, "Ищем друзей рядом…", Toast.LENGTH_SHORT).show()
                    val j = JSONObject().put("k", "shake").put("i", myId).put("n", curName)
                        .put("a", p.latitude).put("o", p.longitude).put("t", t)
                    Thread { postText(base, j.toString()) }.start()
                }
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { sm.registerListener(stepL, it, SensorManager.SENSOR_DELAY_NORMAL) }
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(shakeL, it, SensorManager.SENSOR_DELAY_GAME) }
        onDispose { sm.unregisterListener(stepL); sm.unregisterListener(shakeL) }
    }
    val map = remember {
        MapView(ctx).apply {
            setTileSource(object : OnlineTileSourceBase("EsriStreet", 0, 19, 256, "",
                arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/"), "© Esri, OpenStreetMap") {
                override fun getTileURLString(t: Long): String =
                    baseUrl + MapTileIndex.getZoom(t) + "/" + MapTileIndex.getY(t) + "/" + MapTileIndex.getX(t)
            }); setMultiTouchControls(true)
            minZoomLevel = 7.0; setScrollableAreaLimitDouble(BoundingBox(54.95, 49.8, 52.9, 45.6))
            controller.setZoom(9.0); controller.setCenter(GeoPoint(54.33, 48.39))
        }
    }
    DisposableEffect(Unit) { map.onResume(); onDispose { map.onPause() } }

    Scaffold(
        containerColor = Milk,
        bottomBar = {
            NavigationBar(containerColor = Panel, modifier = Modifier.clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))) {
                listOf("Карта" to Icons.Default.Place, "Друзья" to Icons.Default.Favorite, "Чат" to Icons.Default.Email, "Я" to Icons.Default.Person)
                    .forEachIndexed { i, (t, ic) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(ic, null, Modifier.scale(animateFloatAsState(if (tab == i) 1.25f else 1f, tween(250), label = "ic").value)) }, label = { Text(t) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Deep, selectedTextColor = Deep, indicatorColor = Lavender)
                        )
                    }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            AndroidView(factory = { map }, modifier = Modifier.fillMaxSize(), update = { m ->
                m.overlays.clear()
                m.overlayManager.tilesOverlay.setColorFilter(if (darkTheme) TilesOverlay.INVERT_COLORS else null)
                me?.let { p ->
                    m.overlays.add(Marker(m).apply {
                        position = p; title = name; icon = iconCache.getOrPut("me|" + myEmoji + "|" + System.identityHashCode(myPhoto) + "|" + darkTheme) { avatar(ctx, "Я", -1, 0, Deep.toArgb(), myEmoji, myPhoto) }
                        setAnchor(Marker.ANCHOR_CENTER, 0.32f)
                    })
                }
                friends.values.forEach { f ->
                    m.overlays.add(Marker(m).apply {
                        position = GeoPoint(f.lat, f.lng); title = f.name
                        icon = iconCache.getOrPut(f.name + "|" + f.bat + "|" + f.speed + "|" + f.id + "|" + f.emoji + "|" + System.identityHashCode(photos[f.id])) { avatar(ctx, f.name, f.bat, f.speed, colorFor(f.id).toArgb(), f.emoji, photos[f.id]) }
                        setAnchor(Marker.ANCHOR_CENTER, 0.32f)
                    })
                }
                checkins.takeLast(30).forEach { c ->
                    m.overlays.add(Marker(m).apply { position = GeoPoint(c.lat, c.lng); title = c.place + " — " + c.name })
                }
                val mp = me
                if (mp != null && !centered) {
                    centered = true
                    if (mp.latitude in 52.9..54.95 && mp.longitude in 45.6..49.8) m.controller.animateTo(mp, 15.0, 1000L)
                }
                focus?.let { m.controller.animateTo(it, 16.0, 800L); focus = null }
                m.invalidate()
            })
            if (tab == 0) {
                Text("© Esri, OpenStreetMap", fontSize = 11.sp, color = Ink,
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
                        .background(Panel.copy(alpha = 0.85f), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                Card(
                    Modifier.align(Alignment.TopCenter).padding(12.dp).animateContentSize(),
                    shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Text(
                        (if (frozen) "❄ Заморозка · " else "") + "Ульяновская обл. · друзей: ${friends.size} · " + (if (online) "онлайн" else "подключение…"),
                        Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = Ink, style = MaterialTheme.typography.labelLarge
                    )
                }
                SmallFloatingActionButton(
                    onClick = { me?.let { focus = it } }, containerColor = Panel,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                ) { Icon(Icons.Default.Place, null, tint = Deep) }
            }
            AnimatedVisibility(visible = tab != 0, enter = fadeIn(tween(250)) + slideInVertically(tween(300)) { it / 12 }, exit = fadeOut(tween(200))) {
            Surface(Modifier.fillMaxSize(), color = Milk) {
            AnimatedContent(targetState = tab, transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (fadeIn(tween(280)) + slideInHorizontally(tween(320)) { it / 5 * dir }) togetherWith
                    (fadeOut(tween(200)) + slideOutHorizontally(tween(320)) { -it / 5 * dir })
            }, label = "tab") { t ->
                if (t == 2) {
                    Column(Modifier.fillMaxSize().padding(12.dp)) {
                        Text("Чат комнаты", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        LazyColumn(Modifier.weight(1f), reverseLayout = true) {
                            items(chat.reversed()) { m ->
                                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
                                    Text(if (m.mine) "Вы" else m.name, style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = 0.6f))
                                    if (m.url.isNotEmpty()) NetImage(m.url)
                                    else if (m.big) Text(m.text, fontSize = 56.sp)
                                    else if (m.text.isEmpty()) Text("🖼", fontSize = 32.sp)
                                    else Surface(
                                        shape = RoundedCornerShape(18.dp, 18.dp, if (m.mine) 18.dp else 4.dp, if (m.mine) 4.dp else 18.dp),
                                        color = if (m.mine) Deep else Panel, shadowElevation = 1.dp
                                    ) {
                                        Text(m.text, Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                            color = if (m.mine) MaterialTheme.colorScheme.onPrimary else Ink)
                                    }
                                }
                            }
                        }
                        AnimatedVisibility(panel != 0) {
                            LazyVerticalGrid(GridCells.Adaptive(if (panel == 2) 64.dp else 46.dp), Modifier.heightIn(max = 180.dp)) {
                                items(if (panel == 2) stickers else emojis) { e ->
                                    Text(e, fontSize = if (panel == 2) 40.sp else 26.sp,
                                        modifier = Modifier.clickable { if (panel == 2) sendChat(e, true) else draft += e }.padding(6.dp))
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("😊", fontSize = 24.sp, modifier = Modifier.clickable { panel = if (panel == 1) 0 else 1 }.padding(4.dp))
                            Text("🗿", fontSize = 24.sp, modifier = Modifier.clickable { panel = if (panel == 2) 0 else 2 }.padding(4.dp))
                            Text("🖼", fontSize = 24.sp, modifier = Modifier.clickable { pick.launch("image/*") }.padding(4.dp))
                            OutlinedTextField(draft, { draft = it }, Modifier.weight(1f), placeholder = { Text("Сообщение") }, singleLine = true)
                            Spacer(Modifier.width(6.dp))
                            Button(onClick = {
                                val tx = draft.trim()
                                if (tx.isNotEmpty()) { sendChat(tx, false); draft = "" }
                            }) { Text("➤") }
                        }
                    }
                } else if (t == 1) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Друзья", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        if (friends.isEmpty()) Text("Пока никого. Пригласите друзей во вкладке «Я».", Modifier.padding(top = 12.dp))
                        LazyColumn {
                            items(friends.values.toList()) { f ->
                                val mins = (now - f.ts) / 60000
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(20.dp)).background(Panel).clickable { focus = GeoPoint(f.lat, f.lng); tab = 0 }.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AvatarBox(48.dp, f.name, colorFor(f.id), f.emoji, photos[f.id])
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(f.name, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            (if (f.bat >= 0) "🔋${f.bat}% · " else "") + (if (f.steps >= 0) "👣${f.steps} · " else "") + (if (f.speed > 3) "${f.speed} км/ч · " else "") +
                                                (if (mins < 1) "сейчас онлайн" else "был(а) $mins мин назад"),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else if (t == 3) {
                    AnimatedContent(targetState = settings, transitionSpec = {
                        if (targetState) (slideInHorizontally(tween(300)) { it } + fadeIn(tween(250))) togetherWith
                            (slideOutHorizontally(tween(300)) { -it / 3 } + fadeOut(tween(200)))
                        else (slideInHorizontally(tween(300)) { -it / 3 } + fadeIn(tween(250))) togetherWith
                            (slideOutHorizontally(tween(300)) { it } + fadeOut(tween(200)))
                    }, label = "set") { st ->
                        if (st) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("←", fontSize = 26.sp, modifier = Modifier.clickable { settings = false }.padding(end = 14.dp))
                                    Text("Настройки", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(12.dp))
                                SettingRow("🌙 Тёмная тема", "Тёмное оформление и карта", darkTheme) { darkTheme = it; prefs.edit().putBoolean("dark", it).apply() }
                                SettingRow("❄ Режим заморозки", "Друзья видят только последнюю позицию", frozen) { frozen = it }
                                Text("Код комнаты: $room", Modifier.padding(top = 12.dp, bottom = 4.dp), color = Deep, fontWeight = FontWeight.SemiBold)
                                Text("Данные идут через ntfy.sh. Не публикуйте код комнаты открыто.", style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(16.dp))
                                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = onLeave) { Text("Выйти из комнаты") }
                            }
                        } else {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("⚙", fontSize = 28.sp, modifier = Modifier.align(Alignment.End).clickable { settings = true }.padding(4.dp))
                                AvatarBox(104.dp, name, Deep, myEmoji, myPhoto, Modifier.clickable { avaPick.launch("image/*") })
                                Text("Нажмите на аватарку, чтобы выбрать фото, или выберите эмодзи:", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                                LazyRow(Modifier.padding(vertical = 6.dp)) {
                                    items(emojis) { e ->
                                        Text(e, fontSize = 28.sp, modifier = Modifier.clickable {
                                            myEmoji = e; myPhoto = null
                                            prefs.edit().putString("emoji", e).remove("ava").apply(); sendAva("")
                                        }.padding(6.dp))
                                    }
                                }
                                OutlinedTextField(nick, { nick = it.take(20) }, label = { Text("Ник") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Button(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), onClick = {
                                    if (nick.isNotBlank()) { onName(nick.trim()); Toast.makeText(ctx, "Профиль сохранён", Toast.LENGTH_SHORT).show() }
                                }) { Text("Сохранить ник") }
                                Text("👣 Шагов сегодня: " + (if (mySteps >= 0) mySteps.toString() else "—"), Modifier.padding(top = 12.dp))
                                Button(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), onClick = {
                                    val i = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "Присоединяйся ко мне в «Где друзья»! Код комнаты: $room")
                                    }
                                    ctx.startActivity(Intent.createChooser(i, null))
                                }) { Text("Пригласить друзей") }
                                OutlinedTextField(place, { place = it }, label = { Text("Чекин: название места") }, singleLine = true,
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                                Button(modifier = Modifier.fillMaxWidth(), onClick = {
                                    val pp = me
                                    if (pp != null && place.isNotBlank()) {
                                        val j = JSONObject().put("k", "chk").put("i", myId).put("n", name).put("p", place.trim())
                                            .put("a", pp.latitude).put("o", pp.longitude).put("t", System.currentTimeMillis())
                                        Thread { postText(base, j.toString()) }.start(); place = ""
                                    } else Toast.makeText(ctx, "Нужны геопозиция и название места", Toast.LENGTH_SHORT).show()
                                }) { Text("📍 Отметиться здесь") }
                            }
                        }
                    }
                }
}}}}}}
